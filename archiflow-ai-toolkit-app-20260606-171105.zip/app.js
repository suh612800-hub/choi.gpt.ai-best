const form = document.querySelector("#projectForm");
const tabs = document.querySelectorAll(".tab");
const panels = {
  report: document.querySelector("#reportPanel"),
  checklist: document.querySelector("#checklistPanel"),
  script: document.querySelector("#scriptPanel"),
  compare: document.querySelector("#comparePanel"),
};

const state = {
  markdown: "",
};

const samples = {
  projectName: "도시형 공유 작업 주거",
  projectStage: "중간 발표",
  designBrief:
    "좁은 필지의 깊이를 활용해 주거와 소규모 작업실을 결합한다. 1층은 골목과 연결되는 공유 마당으로 열고, 상부 주거층은 빛과 환기를 위해 중정을 둔다.",
  feedback:
    "중정의 크기와 채광 효과를 수치보다 공간 경험으로 설명할 것. 공용 계단이 단순 이동 동선이 아니라 커뮤니티 장치로 읽히게 할 것. 골목 입면의 스케일을 주변 건물과 비교할 것.",
  analysisNotes:
    "동측 골목은 생활 소음이 많고 서측은 오후 빛이 강하다. 지상층에는 공유 주방과 전시 벽을 배치한다. 2층부터는 복층 작업실과 소형 주거를 교차 배치해 시선이 마주치는 지점을 만든다.",
};

function splitItems(text) {
  return text
    .split(/\n|\.|;|ㆍ|-/)
    .map((item) => item.replace(/^\d+\s*/, "").trim())
    .filter((item) => item.length > 0);
}

function extractKeywords(text) {
  const stopwords = new Set([
    "그리고",
    "하지만",
    "위해",
    "한다",
    "있다",
    "통해",
    "공간",
    "설계",
    "배치",
    "계획",
    "더",
    "것",
  ]);
  const words = text
    .replace(/[^\uAC00-\uD7A3a-zA-Z0-9\s]/g, " ")
    .split(/\s+/)
    .map((word) => word.trim())
    .filter((word) => word.length >= 2 && !stopwords.has(word));

  return [...new Set(words)].slice(0, 10);
}

function classifyItem(item) {
  if (/단면|경사|층|레벨|채광|환기/.test(item)) return "단면";
  if (/동선|진입|계단|보행|연결/.test(item)) return "동선";
  if (/입면|외피|루버|재료|스케일/.test(item)) return "입면";
  if (/다이어그램|설명|비교|발표/.test(item)) return "표현";
  return "검토";
}

function getFormData() {
  return {
    projectName: document.querySelector("#projectName").value.trim() || "무제 프로젝트",
    projectStage: document.querySelector("#projectStage").value,
    designBrief: document.querySelector("#designBrief").value.trim(),
    feedback: document.querySelector("#feedback").value.trim(),
    analysisNotes: document.querySelector("#analysisNotes").value.trim(),
  };
}

function buildResult(data) {
  const feedbackItems = splitItems(data.feedback);
  const noteItems = splitItems(data.analysisNotes);
  const keywords = extractKeywords(`${data.designBrief} ${data.feedback} ${data.analysisNotes}`);
  const checklist = feedbackItems.map((item, index) => ({
    task: item,
    tag: classifyItem(item),
    output: index % 2 === 0 ? "도면" : "다이어그램",
  }));

  const scripts = [
    `${data.projectName}은 ${data.designBrief.replace(/\.$/, "")}는 방향에서 출발합니다.`,
    `대지 분석에서는 ${noteItems[0] || "주변 조건"}을 핵심 조건으로 보고, 이를 진입과 공용공간의 구성으로 연결했습니다.`,
    `교수님 피드백 중 가장 중요한 지점은 ${feedbackItems[0] || "설계 논리의 명확화"}이며, 도면에서는 이 부분을 우선 보완해야 합니다.`,
    `최종 표현에서는 ${keywords.slice(0, 3).join(", ")}을 중심 키워드로 삼아 평면, 단면, 다이어그램의 메시지를 일관되게 맞추겠습니다.`,
  ];

  return {
    feedbackItems,
    noteItems,
    keywords,
    checklist,
    scripts,
  };
}

function renderReport(data, result) {
  panels.report.innerHTML = `
    <h2>분석 리포트</h2>
    <p><strong>${data.projectStage}</strong> 단계의 핵심은 설계 의도를 도면, 단면, 발표 문장으로 같은 방향에 맞추는 것입니다.</p>
    <div class="report-grid">
      <div class="insight-box">
        <strong>설계 개념</strong>
        <p>${data.designBrief}</p>
      </div>
      <div class="insight-box">
        <strong>대지와 공간 조건</strong>
        <p>${result.noteItems.slice(0, 3).join(". ")}.</p>
      </div>
      <div class="insight-box">
        <strong>우선 보완점</strong>
        <p>${result.feedbackItems.slice(0, 3).join(". ")}.</p>
      </div>
      <div class="insight-box">
        <strong>핵심 키워드</strong>
        <p>${result.keywords.join(" · ")}</p>
      </div>
    </div>
    <h3>정리 방향</h3>
    <p>발표 자료에서는 진입 경험, 프로그램 관계, 단면 논리를 하나의 흐름으로 보여주는 구성이 적합합니다. 피드백은 단순 수정 목록으로 두기보다 각 항목이 어떤 도면 또는 다이어그램에서 해결되는지 연결해 관리하는 편이 좋습니다.</p>
  `;
}

function renderChecklist(result) {
  panels.checklist.innerHTML = `
    <h2>수정 체크리스트</h2>
    <ul class="checklist">
      ${result.checklist
        .map(
          (item) => `
            <li>
              <span class="check-box" aria-hidden="true"></span>
              <span>${item.task}</span>
              <span class="tag">${item.tag} · ${item.output}</span>
            </li>
          `,
        )
        .join("")}
    </ul>
  `;
}

function renderScript(result) {
  panels.script.innerHTML = `
    <h2>발표 문장</h2>
    ${result.scripts.map((line) => `<p class="script-line">${line}</p>`).join("")}
  `;
}

function renderCompare(data) {
  panels.compare.innerHTML = `
    <h2>AI 도구 활용 비교</h2>
    <table class="compare-table">
      <thead>
        <tr>
          <th>도구</th>
          <th>적합한 작업</th>
          <th>${data.projectName} 적용 예시</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>GPT</td>
          <td>발표 문장, 설계 의도 정리, 대안 문장 생성</td>
          <td>설계 개념을 교수님 피드백과 연결해 발표용 문장으로 다듬기</td>
        </tr>
        <tr>
          <td>Claude</td>
          <td>긴 피드백 요약, 논리 구조 점검, 글 흐름 정리</td>
          <td>대지 분석과 프로그램 관계를 긴 리포트 형식으로 재구성하기</td>
        </tr>
        <tr>
          <td>Codex</td>
          <td>체크리스트 자동화, 파일 생성, 반복 작업 도구화</td>
          <td>리포트와 체크리스트를 Markdown 파일로 내보내는 작업 만들기</td>
        </tr>
      </tbody>
    </table>
  `;
}

function buildMarkdown(data, result) {
  return `# ${data.projectName}

## 분석 리포트

- 단계: ${data.projectStage}
- 설계 방향: ${data.designBrief}
- 핵심 키워드: ${result.keywords.join(", ")}

## 피드백 기반 체크리스트

${result.checklist.map((item) => `- [ ] [${item.tag}] ${item.task} (${item.output})`).join("\n")}

## 발표 문장

${result.scripts.map((line, index) => `${index + 1}. ${line}`).join("\n")}

## AI 도구 활용 비교

| 도구 | 적합한 작업 | 적용 예시 |
| --- | --- | --- |
| GPT | 발표 문장, 설계 의도 정리, 대안 문장 생성 | 설계 개념을 교수님 피드백과 연결 |
| Claude | 긴 피드백 요약, 논리 구조 점검, 글 흐름 정리 | 대지 분석과 프로그램 관계를 리포트로 재구성 |
| Codex | 체크리스트 자동화, 파일 생성, 반복 작업 도구화 | 결과를 Markdown으로 내보내기 |
`;
}

function updateMetrics(result) {
  document.querySelector("#feedbackCount").textContent = result.feedbackItems.length;
  document.querySelector("#keywordCount").textContent = result.keywords.length;
  document.querySelector("#sentenceCount").textContent = result.scripts.length;
}

function renderAll() {
  const data = getFormData();
  const result = buildResult(data);
  document.querySelector("#pageTitle").textContent = data.projectName;
  updateMetrics(result);
  renderReport(data, result);
  renderChecklist(result);
  renderScript(result);
  renderCompare(data);
  state.markdown = buildMarkdown(data, result);
}

function showToast(message) {
  const toast = document.querySelector("#toast");
  toast.textContent = message;
  toast.classList.add("show");
  window.setTimeout(() => toast.classList.remove("show"), 1600);
}

tabs.forEach((tab) => {
  tab.addEventListener("click", () => {
    tabs.forEach((item) => item.classList.remove("active"));
    Object.values(panels).forEach((panel) => panel.classList.remove("active"));
    tab.classList.add("active");
    panels[tab.dataset.tab].classList.add("active");
  });
});

form.addEventListener("submit", (event) => {
  event.preventDefault();
  renderAll();
  showToast("생성됨");
});

document.querySelector("#sampleButton").addEventListener("click", () => {
  Object.entries(samples).forEach(([key, value]) => {
    document.querySelector(`#${key}`).value = value;
  });
  renderAll();
});

document.querySelector("#copyButton").addEventListener("click", async () => {
  try {
    await navigator.clipboard.writeText(state.markdown);
  } catch {
    const fallback = document.createElement("textarea");
    fallback.value = state.markdown;
    document.body.appendChild(fallback);
    fallback.select();
    document.execCommand("copy");
    fallback.remove();
  }
  showToast("복사됨");
});

document.querySelector("#downloadButton").addEventListener("click", () => {
  const blob = new Blob([state.markdown], { type: "text/markdown;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = "archiflow-report.md";
  link.click();
  URL.revokeObjectURL(url);
});

renderAll();
